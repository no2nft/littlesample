﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace CoreUploadBigFile.Pages
{

    public class BufferedMultipleFileUploadPhysical
    {
        [Required]
        [Display(Name = "File")]
        public List<IFormFile> FormFiles { get; set; }

        [Display(Name = "Note")]
        [StringLength(50, MinimumLength = 0)]
        public string Note { get; set; }
    }

    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
        }

        public void OnGet()
        {

        }

        [BindProperty]
        public BufferedMultipleFileUploadPhysical FileUpload { get; set; }

        public IActionResult OnPostUploadAsync()
        {
            var dir = AppDomain.CurrentDomain.BaseDirectory;

            if (!System.IO.Directory.Exists(dir))
            {
                return Page();
            }




            if (FileUpload.FormFiles == null)
            {
                return Page();
            }

            foreach (var formFile in FileUpload.FormFiles)
            {
                using (var ms = new MemoryStream())
                {
                    formFile.CopyTo(ms);
                    var fileBytes = ms.ToArray();
                    System.IO.File.WriteAllBytes(dir + formFile.FileName, fileBytes);
                }
            }
            return Page();
       
        }
    }
}
